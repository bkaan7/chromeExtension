const SERVICES = {
    arksigner: {
        urls: ['https://127.0.0.1:8443', 'http://127.0.0.1:8080'], 
        statusId: 'arksigner-status',
        versionId: 'arksigner-ver'
    },
    ibsigner: {
        urls: ['http://127.0.0.1:9595', 'https://127.0.0.1:9595'], 
        statusId: 'ibsigner-status',
        versionId: 'ibsigner-ver'
    }
};

async function checkService(serviceKey) {
    const service = SERVICES[serviceKey];
    const statusEl = document.getElementById(service.statusId);
    const versionEl = document.getElementById(service.versionId);

    if (!statusEl || !versionEl) return false;

    for (const url of service.urls) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 1000);

            // no-cors modu tarayıcı güvenlik duvarını (CORS) aşmak için şarttır
            await fetch(url, { method: 'GET', mode: 'no-cors', signal: controller.signal });
            clearTimeout(timeoutId);

            statusEl.textContent = "AKTİF";
            statusEl.className = "status-badge online";
            versionEl.textContent = "Bağlantı Başarılı.";
            return true;
        } catch (error) {
            continue;
        }
    }

    statusEl.textContent = "KAPALI";
    statusEl.className = "status-badge offline";
    versionEl.textContent = "Bağlantı Kurulamadı.";
    return false;
}

async function scanAll() {
    const akiaStatus = document.getElementById('akia-status');
    const akiaVer = document.getElementById('akia-ver');
    
    if (akiaStatus && akiaVer) {
        akiaStatus.textContent = "...";
        akiaStatus.className = "status-badge offline";
        akiaVer.textContent = "Sürücü katmanı taranıyor...";
    }

    const arkIsOnline = await checkService('arksigner');
    const ibIsOnline = await checkService('ibsigner');

    // MANTIKSAL DOĞRULAMA:
    // Yazılım katmanı çalışıyorsa sürücü mimarisi hazırdır. 
    // Altındaki metinle kullanıcıya USB uyarısını hatırlatıyoruz.
    if (akiaStatus && akiaVer) {
        if (arkIsOnline || ibIsOnline) {
            akiaStatus.textContent = "AKTİF";
            akiaStatus.className = "status-badge online";
            akiaVer.textContent = "Sürücü hazır. (Lütfen e-imza USB'nizin takılı olduğundan emin olun).";
        } else {
            akiaStatus.textContent = "RİSKLİ";
            akiaStatus.className = "status-badge offline";
            akiaVer.textContent = "E-İmza servisleri kapalı.";
        }
    }
}

function clearEImzaCache() {
    const cacheBtn = document.getElementById('btn-clear-cache');
    cacheBtn.textContent = "Temizleniyor...";
    cacheBtn.disabled = true;

    const targetOrigins = [
        "https://nesislemleri.kamusm.gov.tr",
        "https://online.kamusm.gov.tr",
        "https://www.turkiye.gov.tr"
    ];

    chrome.browsingData.remove({
        "origins": targetOrigins
    }, {
        "cache": true,
        "cookies": true,
        "fileSystems": true,
        "indexedDB": true,
        "localStorage": true
    }, () => {
        alert("E-İmza sitelerine ait tarayıcı önbelleği başarıyla temizlendi! Sayfayı yenileyip tekrar imza atmayı deneyebilirsiniz.");
        cacheBtn.textContent = "Önbelleği Temizle";
        cacheBtn.disabled = false;
        scanAll();
    });
}

document.addEventListener('DOMContentLoaded', () => {
    scanAll();
    const refreshBtn = document.getElementById('btn-refresh');
    if (refreshBtn) refreshBtn.addEventListener('click', scanAll);
    const cacheBtn = document.getElementById('btn-clear-cache');
    if (cacheBtn) cacheBtn.addEventListener('click', clearEImzaCache);
});